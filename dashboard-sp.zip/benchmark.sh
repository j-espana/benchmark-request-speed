#!/bin/bash

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}================================${NC}"
echo -e "${YELLOW}  API Speed Benchmark Test${NC}"
echo -e "${YELLOW}================================${NC}"
echo ""

# Verificar que wrk esté instalado
if ! command -v wrk &> /dev/null
then
    echo -e "${RED}wrk no está instalado. Instálalo con:${NC}"
    echo "  macOS: brew install wrk"
    echo "  Ubuntu: sudo apt-get install wrk"
    exit 1
fi

# Verificar que los servidores estén corriendo
echo "Verificando servidores..."
echo ""

check_server() {
    if curl -s "http://localhost:$1/api/data" > /dev/null; then
        echo -e "${GREEN}✓ $2 (Puerto $1) está corriendo${NC}"
        return 0
    else
        echo -e "${RED}✗ $2 (Puerto $1) NO está corriendo${NC}"
        return 1
    fi
}

FASTAPI_OK=false
GIN_OK=false
ACTIX_OK=false

check_server 8000 "FastAPI" && FASTAPI_OK=true
check_server 8001 "Gin" && GIN_OK=true
check_server 8002 "Actix-web" && ACTIX_OK=true

echo ""

if ! $FASTAPI_OK && ! $GIN_OK && ! $ACTIX_OK; then
    echo -e "${RED}Ningún servidor está corriendo. Inicia al menos uno antes de ejecutar el benchmark.${NC}"
    exit 1
fi

echo -e "${YELLOW}Iniciando benchmarks...${NC}"
echo ""

# Benchmark FastAPI
if $FASTAPI_OK; then
    echo -e "${YELLOW}=== Benchmark FastAPI (Puerto 8000) ===${NC}"
    wrk -t4 -c100 -d10s http://localhost:8000/api/data
    echo ""
fi

# Benchmark Gin
if $GIN_OK; then
    echo -e "${YELLOW}=== Benchmark Gin (Puerto 8001) ===${NC}"
    wrk -t4 -c100 -d10s http://localhost:8001/api/data
    echo ""
fi

# Benchmark Actix-web
if $ACTIX_OK; then
    echo -e "${YELLOW}=== Benchmark Actix-web (Puerto 8002) ===${NC}"
    wrk -t4 -c100 -d10s http://localhost:8002/api/data
    echo ""
fi

echo -e "${GREEN}================================${NC}"
echo -e "${GREEN}  Benchmark completado!${NC}"
echo -e "${GREEN}================================${NC}"
