use actix_web::{get, web, App, HttpResponse, HttpServer, Responder};
use serde::{Deserialize, Serialize};
use chrono::Utc;

#[derive(Serialize, Deserialize)]
struct User {
    id: i32,
    name: String,
    email: String,
    age: i32,
    city: String,
}

#[derive(Serialize, Deserialize)]
struct DataContent {
    users: Vec<User>,
    total: i32,
    timestamp: String,
}

#[derive(Serialize, Deserialize)]
struct Response {
    message: String,
    data: DataContent,
}

#[get("/api/data")]
async fn get_data() -> impl Responder {
    let users = vec![
        User {
            id: 1,
            name: "John Doe".to_string(),
            email: "john@example.com".to_string(),
            age: 30,
            city: "New York".to_string(),
        },
        User {
            id: 2,
            name: "Jane Smith".to_string(),
            email: "jane@example.com".to_string(),
            age: 25,
            city: "Los Angeles".to_string(),
        },
        User {
            id: 3,
            name: "Bob Johnson".to_string(),
            email: "bob@example.com".to_string(),
            age: 35,
            city: "Chicago".to_string(),
        },
        User {
            id: 4,
            name: "Alice Williams".to_string(),
            email: "alice@example.com".to_string(),
            age: 28,
            city: "Houston".to_string(),
        },
        User {
            id: 5,
            name: "Charlie Brown".to_string(),
            email: "charlie@example.com".to_string(),
            age: 32,
            city: "Phoenix".to_string(),
        },
    ];

    let response = Response {
        message: "Success".to_string(),
        data: DataContent {
            users,
            total: 5,
            timestamp: Utc::now().to_rfc3339(),
        },
    };

    HttpResponse::Ok().json(response)
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    println!("Starting server at http://0.0.0.0:8002");

    HttpServer::new(|| {
        App::new()
            .service(get_data)
    })
    .bind(("0.0.0.0", 8002))?
    .run()
    .await
}
