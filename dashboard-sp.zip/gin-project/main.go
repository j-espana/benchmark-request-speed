package main

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

type User struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Email string `json:"email"`
	Age   int    `json:"age"`
	City  string `json:"city"`
}

type Response struct {
	Message string      `json:"message"`
	Data    interface{} `json:"data"`
}

type DataContent struct {
	Users     []User `json:"users"`
	Total     int    `json:"total"`
	Timestamp string `json:"timestamp"`
}

func main() {
	gin.SetMode(gin.ReleaseMode)
	r := gin.Default()

	r.GET("/api/data", func(c *gin.Context) {
		users := []User{
			{ID: 1, Name: "John Doe", Email: "john@example.com", Age: 30, City: "New York"},
			{ID: 2, Name: "Jane Smith", Email: "jane@example.com", Age: 25, City: "Los Angeles"},
			{ID: 3, Name: "Bob Johnson", Email: "bob@example.com", Age: 35, City: "Chicago"},
			{ID: 4, Name: "Alice Williams", Email: "alice@example.com", Age: 28, City: "Houston"},
			{ID: 5, Name: "Charlie Brown", Email: "charlie@example.com", Age: 32, City: "Phoenix"},
		}

		response := Response{
			Message: "Success",
			Data: DataContent{
				Users:     users,
				Total:     5,
				Timestamp: time.Now().Format(time.RFC3339),
			},
		}

		c.JSON(http.StatusOK, response)
	})

	r.Run(":8001")
}
