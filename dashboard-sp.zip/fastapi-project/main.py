from fastapi import FastAPI
from datetime import datetime
import uvicorn

app = FastAPI()

@app.get("/api/data")
async def get_data():
    return {
        "message": "Success",
        "data": {
            "users": [
                {"id": 1, "name": "John Doe", "email": "john@example.com", "age": 30, "city": "New York"},
                {"id": 2, "name": "Jane Smith", "email": "jane@example.com", "age": 25, "city": "Los Angeles"},
                {"id": 3, "name": "Bob Johnson", "email": "bob@example.com", "age": 35, "city": "Chicago"},
                {"id": 4, "name": "Alice Williams", "email": "alice@example.com", "age": 28, "city": "Houston"},
                {"id": 5, "name": "Charlie Brown", "email": "charlie@example.com", "age": 32, "city": "Phoenix"}
            ],
            "total": 5,
            "timestamp": datetime.now().isoformat()
        }
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
